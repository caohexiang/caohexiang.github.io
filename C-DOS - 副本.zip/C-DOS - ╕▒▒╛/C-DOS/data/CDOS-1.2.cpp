#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <sstream>
#include <cctype>
#include <io.h>
#include <ctime>
#include <direct.h>
#include <iomanip>

using namespace std;

// ��������
void delay(DWORD milliseconds);
void normalizeDriveLetter(string& path);
void printColored(const string& message, const string& colorCode);
void printError(const string& message);
void printWritePrompt(const string& message);
void printList(const string& message);
void printSuccess(const string& message);
void printGame(const string& message);
string formatFileTime(time_t fileTime);
string intToString(long long num);

bool createFileWithPath(const string& filename, const string& directory);
bool deleteFileWithPath(const string& filename, const string& directory);
bool writeFileWithPath(const string& filename, const string& directory);
bool traverseDirectoryEnhanced(const string& path);
bool runFileWithPath(const string& filename, const string& directory);
void startGame();
bool changeDirectory(const string& targetDir);
void clearScreen();  // ������������

bool parseCommand(const string& command, string& operation, string& filename, string& directory);
void processCommand(const string& command);
void initCurrentDir();
void bootCdos();
void commandLine();
void printCommandSummary();  // ������ܴ�ӡ����

// ȫ�ֱ����볣��
string g_currentDir;
const string COLOR_DEFAULT = "color 07";
const string COLOR_ERROR = "color 0C";
const string COLOR_PROMPT = "color 0A";
const string COLOR_LIST = "color 0B";
const string COLOR_SUCCESS = "color 0F";
const string COLOR_GAME = "color 0E";

// ��������ʵ�֣������Ļ�������������
void clearScreen() {
    // ����ϵͳ��������
    system("cls");
    // �������������Ϣ
    system(COLOR_DEFAULT.c_str());  // ��ʼ��Ĭ����ɫ
   	cout << "C-DOS Version 1.09 (C) Copyright 1995 C-DOS Development Team" << endl;
    
    cout << "System BIOS v1.0.5 - Initializing hardware..." << endl;

	cout<<endl<<endl;
    cout << "Checking system memory..." << endl;

    cout << "640K conventional memory detected (OK)" << endl;


    cout << "Checking disk drives..." << endl;
    cout<<endl;
   
    cout << "Drive A: 3.5\" 1.44MB Floppy Disk (Ready)" << endl;
    cout << "Drive C: 200MB Fixed Disk (Active Partition)" << endl;
    
	cout<<endl;
    cout << "Loading system components..." << endl;
  
    cout << "IO.SYS loaded (v1.0)" << endl;
  
    cout << "MSDOS.SYS loaded (v1.0)" << endl;
   
    cout << "COMMAND.COM loaded (v1.0) - Shell ready" << endl;

    cout << endl << "C-DOS startup completed successfully" << endl;

	cout << "\n[Supported Commands Summary]" << endl;
    cout << "new_[file]_to_[path]  - Create empty file" << endl;
    cout << "del_[file]_to_[path]  - Delete existing file" << endl;
    cout << "idl_[file]_to_[path]  - Create and write file" << endl;
    cout << "run_[file]_to_[path]  - Run file with default program" << endl;
    cout << "cd_[path]            - Change current directory" << endl;
    cout << "tra_[path]            - List files (with size/time)" << endl;
    cout << "::game                - Play number guessing game" << endl;
    cout << "::cls                 - Clear screen (keep commands)" << endl;  // ������������˵��
    cout << "exit                  - Shutdown C-DOS" << endl;
}

// ���ߺ���ʵ��
void delay(DWORD milliseconds) { Sleep(milliseconds); }

void normalizeDriveLetter(string& path) {
    if (path.length() >= 2 && path[1] == ':' && tolower(path[0]) == 'c') {
        path[0] = 'C';
    }
}

void printColored(const string& message, const string& colorCode) {
    system(colorCode.c_str());
    cout << message << endl;
    system(COLOR_DEFAULT.c_str());
}

void printError(const string& message) { printColored(message, COLOR_ERROR); }
void printWritePrompt(const string& message) { printColored(message, COLOR_PROMPT); }
void printList(const string& message) { printColored(message, COLOR_LIST); }
void printSuccess(const string& message) { printColored(message, COLOR_SUCCESS); }
void printGame(const string& message) { printColored(message, COLOR_GAME); }

string intToString(long long num) {
    stringstream ss;
    ss << num;
    return ss.str();
}

string formatFileTime(time_t fileTime) {
    struct tm* localTime = localtime(&fileTime);
    if (localTime == NULL) return "Unknown Time";

    stringstream ss;
    ss << setfill('0');
    ss << setw(4) << (localTime->tm_year + 1900) << "-";
    ss << setw(2) << (localTime->tm_mon + 1) << "-";
    ss << setw(2) << localTime->tm_mday << " ";
    ss << setw(2) << localTime->tm_hour << ":";
    ss << setw(2) << localTime->tm_min;
    return ss.str();
}

void initCurrentDir() {
    char buffer[256];
    if (_getcwd(buffer, sizeof(buffer)) != NULL) {
        g_currentDir = buffer;
        if (g_currentDir[g_currentDir.length() - 1] != '\\') {
            g_currentDir += "\\";
        }
    } else {
        g_currentDir = "C:\\";
    }
}

// Ŀ¼��������
bool changeDirectory(const string& targetDir) {
    string normalizedDir = targetDir;
    normalizeDriveLetter(normalizedDir);

    string fullDir;
    if (normalizedDir.empty()) {
        printError("Invalid directory: empty path");
        return false;
    }
    if (normalizedDir.find(":\\") != string::npos) {
        fullDir = normalizedDir;
    } else {
        fullDir = g_currentDir + normalizedDir;
    }
    if (fullDir[fullDir.length() - 1] != '\\') {
        fullDir += "\\";
    }

    if (_chdir(fullDir.c_str()) != 0) {
        printError("Failed to enter directory: " + fullDir);
        return false;
    }

    g_currentDir = fullDir;
    printSuccess("Current directory changed to: " + g_currentDir);
    return true;
}

bool traverseDirectoryEnhanced(const string& path) {
    string targetPath = path;
    normalizeDriveLetter(targetPath);

    string fullPath;
    if (targetPath.find(":\\") != string::npos) {
        fullPath = targetPath;
    } else {
        fullPath = g_currentDir + targetPath;
    }
    if (fullPath[fullPath.length() - 1] != '\\') {
        fullPath += "\\";
    }

    string searchPath = fullPath + "*.*";
    _finddata_t fileInfo;
    intptr_t handle = _findfirst(searchPath.c_str(), &fileInfo);

    if (handle == -1L) {
        printError("Directory not found: " + fullPath);
        return false;
    }

    printList("\nDirectory of: " + fullPath);
    printList("----------------------------------------------------------------------");
    cout << left << setw(8) << "[Type]" << setw(25) << "Name" 
         << setw(15) << "Size (Bytes)" << "Modify Time" << endl;
    printList("----------------------------------------------------------------------");

    int fileCount = 0;
    long long totalSize = 0;
    do {
        if (strcmp(fileInfo.name, ".") == 0 || strcmp(fileInfo.name, "..") == 0) continue;

        string typeStr = (fileInfo.attrib & _A_SUBDIR) ? "[DIR]" : "[FILE]";
        string nameStr = fileInfo.name;
        if (fileInfo.attrib & _A_SUBDIR) nameStr += "\\";
        else totalSize += fileInfo.size;
        
        string sizeStr = (fileInfo.attrib & _A_SUBDIR) ? "-" : intToString(fileInfo.size);
        string timeStr = formatFileTime(fileInfo.time_write);

        stringstream lineSS;
        lineSS << left << setw(8) << typeStr << setw(25) << nameStr 
               << setw(15) << sizeStr << timeStr;
        printList(lineSS.str());
        fileCount++;
    } while (_findnext(handle, &fileInfo) == 0);

    _findclose(handle);
    printList("----------------------------------------------------------------------");
    cout << "Total items: " << fileCount << " | Total size: " << totalSize << " bytes" << endl;
    return true;
}

// �ļ���������
bool createFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (checkFile.good()) {
        checkFile.close();
        printError("File already exists: " + fullPath);
        return false;
    }

    ofstream newFile(fullPath.c_str());
    if (newFile.is_open()) {
        newFile.close();
        cout << "Empty file created: " << fullPath << endl;
        return true;
    } else {
        printError("Failed to create file: " + fullPath);
        printError("Check directory existence and permissions");
        return false;
    }
}

bool deleteFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    if (DeleteFileA(fullPath.c_str())) {
        cout << "File deleted: " << fullPath << endl;
        return true;
    } else {
        stringstream ss;
        ss << GetLastError();
        printError("Failed to delete file: " + fullPath + " (Error: " + ss.str() + ")");
        return false;
    }
}

bool writeFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ofstream writeFile(fullPath.c_str());

    if (!writeFile.is_open()) {
        printError("Failed to open file: " + fullPath);
        return false;
    }

    printWritePrompt("\n=== Write Mode ===");
    printWritePrompt("Type '::save' to save, '::cancel' to discard");

    string inputLine;
    while (true) {
        system(COLOR_PROMPT.c_str());
        cout << "[Write] > ";
        system(COLOR_DEFAULT.c_str());
        getline(cin, inputLine);

        if (inputLine == "::save") {
            writeFile.close();
            cout << "Saved to: " << fullPath << endl;
            return true;
        } else if (inputLine == "::cancel") {
            writeFile.close();
            DeleteFileA(fullPath.c_str());
            printError("Write canceled");
            return false;
        } else {
            writeFile << inputLine << endl;
        }
    }
}

bool runFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    printSuccess("Running: " + fullPath);
    HINSTANCE result = ShellExecuteA(0, "open", fullPath.c_str(), NULL, NULL, SW_SHOWNORMAL);

    if ((intptr_t)result > 32) {
        printSuccess("File started successfully");
        return true;
    } else {
        stringstream ss;
        ss << (intptr_t)result;
        printError("Failed to run file (Error: " + ss.str() + ")");
        return false;
    }
}

// ��Ϸ����
void startGame() {
    system(COLOR_GAME.c_str());
    cout << "\n=== Number Guessing Game ===" << endl;
    cout << "Guess a number between 1-100 (type 'quit' to exit)" << endl;

    srand((unsigned int)time(NULL));
    int secretNumber = rand() % 100 + 1;
    int guess, attempts = 0;
    string input;

    while (true) {
        cout << "\nYour guess: ";
        getline(cin, input);

        if (input == "quit") {
            printError("Secret number was: " + intToString(secretNumber));
            system(COLOR_DEFAULT.c_str());
            return;
        }

        stringstream ss(input);
        if (!(ss >> guess)) {
            printError("Enter a valid number or 'quit'");
            continue;
        }

        attempts++;
        if (guess < secretNumber) printGame("Too low!");
        else if (guess > secretNumber) printGame("Too high!");
        else {
            system(COLOR_SUCCESS.c_str());
            cout << "Correct! You won in " << attempts << " tries!" << endl;
            system(COLOR_DEFAULT.c_str());
            return;
        }
    }
}

// ��������봦��
bool parseCommand(const string& command, string& operation, string& filename, string& directory) {
    if (command == "::game") {
        operation = "game";
        return true;
    }
    // ����::cls�������
    else if (command == "::cls") {
        operation = "cls";
        return true;
    }
    else if (command.substr(0, 3) == "cd_") {
        operation = "cd";
        directory = command.substr(3);
        filename = "";
    }
    else if (command.substr(0, 4) == "del_") {
        operation = "delete";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    else if (command.substr(0, 4) == "new_") {
        operation = "create";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    else if (command.substr(0, 4) == "idl_") {
        operation = "write";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    else if (command.substr(0, 4) == "tra_") {
        operation = "traverse";
        directory = command.substr(4);
        filename = "";
    }
    else if (command.substr(0, 4) == "run_") {
        operation = "run";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    else {
        return false;
    }

    if (operation != "traverse" && operation != "game" && operation != "cd" && operation != "cls") {
        if (directory == ".") {
            directory = g_currentDir;
        } else {
            normalizeDriveLetter(directory);
            if (!directory.empty() && directory[directory.length() - 1] != '\\') {
                directory += "\\";
            }
        }
    }
    return true;
}

void processCommand(const string& command) {
    if (command == "exit") {
        cout << "Shutting down C-DOS..." << endl;
        delay(1000);
        exit(0);
    }

    if (!command.empty()) {
        string operation, filename, directory;
        if (parseCommand(command, operation, filename, directory)) {
            if (operation == "cd") {
                changeDirectory(directory);
            } else if (operation == "traverse") {
                traverseDirectoryEnhanced(directory);
            } else if (operation == "create") {
                createFileWithPath(filename, directory);
            } else if (operation == "delete") {
                deleteFileWithPath(filename, directory);
            } else if (operation == "write") {
                writeFileWithPath(filename, directory);
            } else if (operation == "run") {
                runFileWithPath(filename, directory);
            } else if (operation == "game") {
                startGame();
            } else if (operation == "cls") {  // ������������
                clearScreen();
            }
        } else {
            printError("\nInvalid command! Supported commands:");
            printCommandSummary();  // ��ʾ�������
        }
    }
}

// ������ܴ�ӡ������������ȡ���ڸ��ã�
void printCommandSummary() {
    cout << "new_[file]_to_[path]  - Create empty file" << endl;
    cout << "del_[file]_to_[path]  - Delete file" << endl;
    cout << "idl_[file]_to_[path]  - Write file content" << endl;
    cout << "run_[file]_to_[path]  - Run file" << endl;
    cout << "cd_[path]            - Change directory" << endl;
    cout << "tra_[path]            - List directory contents" << endl;
    cout << "::game                - Start guessing game" << endl;
    cout << "::cls                 - Clear screen (keep commands)" << endl;  // ������������
    cout << "exit                  - Exit C-DOS" << endl;
}

// �����뽻��
void bootCdos() {
    system(COLOR_DEFAULT.c_str());  // ��ʼ��Ĭ����ɫ
   	cout << "C-DOS Version 1.09 (C) Copyright 1995 C-DOS Development Team" << endl;
    
    cout << "System BIOS v1.0.5 - Initializing hardware..." << endl;
    delay(800);
	cout<<endl<<endl;
    cout << "Checking system memory..." << endl;
    delay(600);
    cout << "640K conventional memory detected (OK)" << endl;
    delay(400);

    cout << "Checking disk drives..." << endl;
    cout<<endl;
    delay(700);
    cout << "Drive A: 3.5\" 1.44MB Floppy Disk (Ready)" << endl;
    cout << "Drive C: 200MB Fixed Disk (Active Partition)" << endl;
    delay(500);
	cout<<endl;
    cout << "Loading system components..." << endl;
    delay(600);
    cout << "IO.SYS loaded (v1.0)" << endl;
    delay(700);
    cout << "MSDOS.SYS loaded (v1.0)" << endl;
    delay(500);
    cout << "COMMAND.COM loaded (v1.0) - Shell ready" << endl;

    cout << endl << "C-DOS startup completed successfully" << endl;
    delay(300);
    
    printCommandSummary();  // ��ʾ�������
}

void commandLine() {
    string command;
    while (true) {
        cout << endl << g_currentDir << ">";
        getline(cin, command);
        processCommand(command);
    }
}

int main() {
    initCurrentDir();
    bootCdos();
    commandLine();
    return 0;
}



