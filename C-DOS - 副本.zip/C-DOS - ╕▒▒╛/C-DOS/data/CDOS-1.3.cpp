#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <sstream>
#include <cctype>
#include <io.h>
#include <ctime>
#include <direct.h>
#include <iomanip>
#include <cstring>

using namespace std;

// ȫ�ֱ����볣��
string g_currentDir;
string g_colorCode = "07";  // Ĭ����ɫ���ڵװ���
const string COLOR_DEFAULT = "color 07";
const string COLOR_ERROR = "color 0C";
const string COLOR_PROMPT = "color 0A";
const string COLOR_LIST = "color 0B";
const string COLOR_SUCCESS = "color 0F";
const string COLOR_GAME = "color 0E";

// ��������
void delay(DWORD milliseconds);
void normalizeDriveLetter(string& path);
void printColored(const string& message, const string& colorCode);
void printError(const string& message);
void printWritePrompt(const string& message);
void printList(const string& message);
void printSuccess(const string& message);
void printGame(const string& message);
string formatFileTime(time_t fileTime);
string intToString(long long num);
string getCurrentDateTime();

bool createFileWithPath(const string& filename, const string& directory);
bool deleteFileWithPath(const string& filename, const string& directory);
bool writeFileWithPath(const string& filename, const string& directory);
bool traverseDirectoryEnhanced(const string& path);
bool runFileWithPath(const string& filename, const string& directory);
void startGame();
bool changeDirectory(const string& targetDir);
void clearScreen();
bool changeColor(const string& colorCode);
void showDateTime();
void showHelp();
bool makeDirectory(const string& path);
bool removeDirectory(const string& path);

bool parseCommand(const string& command, string& operation, string& param1, string& param2);
void processCommand(const string& command);
void initCurrentDir();
void bootCdos();
void commandLine();
void printCommandSummary();

// ���ߺ���ʵ��
void delay(DWORD milliseconds) { Sleep(milliseconds); }

void normalizeDriveLetter(string& path) {
    if (path.length() >= 2 && path[1] == ':' && tolower(path[0]) == 'c') {
        path[0] = 'C';
    }
}

void printColored(const string& message, const string& colorCode) {
    system(colorCode.c_str());
    cout << message << endl;
    string currentColor = "color " + g_colorCode;
    system(currentColor.c_str());
}

void printError(const string& message) { printColored(message, COLOR_ERROR); }
void printWritePrompt(const string& message) { printColored(message, COLOR_PROMPT); }
void printList(const string& message) { printColored(message, COLOR_LIST); }
void printSuccess(const string& message) { printColored(message, COLOR_SUCCESS); }
void printGame(const string& message) { printColored(message, COLOR_GAME); }

// ����ת�ַ�������
string intToString(long long num) {
    stringstream ss;
    ss << num;
    return ss.str();
}

// ��ʽ���ļ�ʱ�亯��
string formatFileTime(time_t fileTime) {
    struct tm* localTime = localtime(&fileTime);
    if (localTime == NULL) return "Unknown Time";

    stringstream ss;
    ss << setfill('0');
    ss << setw(4) << (localTime->tm_year + 1900) << "-";
    ss << setw(2) << (localTime->tm_mon + 1) << "-";
    ss << setw(2) << localTime->tm_mday << " ";
    ss << setw(2) << localTime->tm_hour << ":";
    ss << setw(2) << localTime->tm_min;
    return ss.str();
}

// ��ȡ��ǰ����ʱ���ַ���
string getCurrentDateTime() {
    time_t now = time(0);
    struct tm tstruct;
    char buf[80];
    tstruct = *localtime(&now);
    strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", &tstruct);
    return string(buf);
}

// ��ʼ����ǰĿ¼
void initCurrentDir() {
    char buffer[256];
    if (_getcwd(buffer, sizeof(buffer)) != NULL) {
        g_currentDir = buffer;
        if (g_currentDir[g_currentDir.length() - 1] != '\\') {
            g_currentDir += "\\";
        }
    } else {
        g_currentDir = "C:\\";
    }
}

// Ŀ¼��������
bool changeDirectory(const string& targetDir) {
    string normalizedDir = targetDir;
    normalizeDriveLetter(normalizedDir);

    string fullDir;
    if (normalizedDir.empty()) {
        printError("Invalid directory: empty path");
        return false;
    }
    if (normalizedDir.find(":\\") != string::npos) {
        fullDir = normalizedDir;
    } else {
        fullDir = g_currentDir + normalizedDir;
    }
    if (fullDir[fullDir.length() - 1] != '\\') {
        fullDir += "\\";
    }

    if (_chdir(fullDir.c_str()) != 0) {
        printError("Failed to enter directory: " + fullDir);
        return false;
    }

    g_currentDir = fullDir;
    printSuccess("Current directory changed to: " + g_currentDir);
    return true;
}

bool traverseDirectoryEnhanced(const string& path) {
    string targetPath = path;
    normalizeDriveLetter(targetPath);

    string fullPath;
    if (targetPath.find(":\\") != string::npos) {
        fullPath = targetPath;
    } else {
        fullPath = g_currentDir + targetPath;
    }
    if (fullPath[fullPath.length() - 1] != '\\') {
        fullPath += "\\";
    }

    string searchPath = fullPath + "*.*";
    _finddata_t fileInfo;
    intptr_t handle = _findfirst(searchPath.c_str(), &fileInfo);

    if (handle == -1L) {
        printError("Directory not found: " + fullPath);
        return false;
    }

    printList("\nDirectory of: " + fullPath);
    printList("----------------------------------------------------------------------");
    cout << left << setw(8) << "[Type]" << setw(25) << "Name" 
         << setw(15) << "Size (Bytes)" << "Modify Time" << endl;
    printList("----------------------------------------------------------------------");

    int fileCount = 0;
    long long totalSize = 0;
    do {
        if (strcmp(fileInfo.name, ".") == 0 || strcmp(fileInfo.name, "..") == 0) continue;

        string typeStr = (fileInfo.attrib & _A_SUBDIR) ? "[DIR]" : "[FILE]";
        string nameStr = fileInfo.name;
        if (fileInfo.attrib & _A_SUBDIR) nameStr += "\\";
        else totalSize += fileInfo.size;
        
        string sizeStr = (fileInfo.attrib & _A_SUBDIR) ? "-" : intToString(fileInfo.size);
        string timeStr = formatFileTime(fileInfo.time_write);

        stringstream lineSS;
        lineSS << left << setw(8) << typeStr << setw(25) << nameStr 
               << setw(15) << sizeStr << timeStr;
        printList(lineSS.str());
        fileCount++;
    } while (_findnext(handle, &fileInfo) == 0);

    _findclose(handle);
    printList("----------------------------------------------------------------------");
    cout << "Total items: " << fileCount << " | Total size: " << totalSize << " bytes" << endl;
    return true;
}

// �ļ���������
bool createFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (checkFile.good()) {
        checkFile.close();
        printError("File already exists: " + fullPath);
        return false;
    }

    ofstream newFile(fullPath.c_str());
    if (newFile.is_open()) {
        newFile.close();
        cout << "Empty file created: " << fullPath << endl;
        return true;
    } else {
        printError("Failed to create file: " + fullPath);
        printError("Check directory existence and permissions");
        return false;
    }
}

bool deleteFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    if (DeleteFileA(fullPath.c_str())) {
        cout << "File deleted: " << fullPath << endl;
        return true;
    } else {
        stringstream ss;
        ss << GetLastError();
        printError("Failed to delete file: " + fullPath + " (Error: " + ss.str() + ")");
        return false;
    }
}

bool writeFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ofstream writeFile(fullPath.c_str());

    if (!writeFile.is_open()) {
        printError("Failed to open file: " + fullPath);
        return false;
    }

    printWritePrompt("\n=== Write Mode ===");
    printWritePrompt("Type '::save' to save, '::cancel' to discard");

    string inputLine;
    while (true) {
        system(COLOR_PROMPT.c_str());
        cout << "[Write] > ";
        system(("color " + g_colorCode).c_str());
        getline(cin, inputLine);

        if (inputLine == "::save") {
            writeFile.close();
            cout << "Saved to: " << fullPath << endl;
            return true;
        } else if (inputLine == "::cancel") {
            writeFile.close();
            DeleteFileA(fullPath.c_str());
            printError("Write canceled");
            return false;
        } else {
            writeFile << inputLine << endl;
        }
    }
}

bool runFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    printSuccess("Running: " + fullPath);
    HINSTANCE result = ShellExecuteA(0, "open", fullPath.c_str(), NULL, NULL, SW_SHOWNORMAL);

    if ((intptr_t)result > 32) {
        printSuccess("File started successfully");
        return true;
    } else {
        stringstream ss;
        ss << (intptr_t)result;
        printError("Failed to run file (Error: " + ss.str() + ")");
        return false;
    }
}

// ��Ϸ����
void startGame() {
    system(COLOR_GAME.c_str());
    cout << "\n=== Number Guessing Game ===" << endl;
    cout << "Guess a number between 1-100 (type 'quit' to exit)" << endl;

    srand((unsigned int)time(NULL));
    int secretNumber = rand() % 100 + 1;
    int guess, attempts = 0;
    string input;

    while (true) {
        cout << "\nYour guess: ";
        getline(cin, input);

        if (input == "quit") {
            printError("Secret number was: " + intToString(secretNumber));
            system(("color " + g_colorCode).c_str());
            return;
        }

        stringstream ss(input);
        if (!(ss >> guess)) {
            printError("Enter a valid number or 'quit'");
            continue;
        }

        attempts++;
        if (guess < secretNumber) printGame("Too low!");
        else if (guess > secretNumber) printGame("Too high!");
        else {
            system(COLOR_SUCCESS.c_str());
            cout << "Correct! You won in " << attempts << " tries!" << endl;
            system(("color " + g_colorCode).c_str());
            return;
        }
    }
}

// ��ɫ����
bool changeColor(const string& colorCode) {
    if (colorCode.empty()) {
        printError("Color code missing! Please provide a 2-digit hex code.");
        printError("Example: ::color 0A (black background, green text)");
        printError("Color codes: 0=Black, 1=Blue, 2=Green, 3=Cyan,");
        printError("             4=Red, 5=Magenta, 6=Brown, 7=Light Gray");
        return false;
    }
    
    if (colorCode.length() != 2) {
        printError("Invalid color code. Use 2 hex digits (0-9, A-F)");
        printError("Example: ::color 0A (black background, green text)");
        return false;
    }
    
    for (int i = 0; i < colorCode.length(); i++) {
        char c = colorCode[i];
        if (!isxdigit(c)) {
            printError("Invalid color code. Use hex digits only (0-9, A-F)");
            return false;
        }
    }
    
    string command = "color " + colorCode;
    system(command.c_str());
    g_colorCode = colorCode;
    printSuccess("Color changed to: " + colorCode);
    return true;
}

// ��ʾ����ʱ��
void showDateTime() {
    string dt = getCurrentDateTime();
    cout << "Current date and time: " << dt << endl;
}

// ��������
void showHelp() {
    clearScreen();
    cout << "====================================" << endl;
    cout << "           C-DOS Help               " << endl;
    cout << "====================================" << endl;
    cout << "File Operations:" << endl;
    cout << "  new_[file]_to_[path]    Create empty file" << endl;
    cout << "  del_[file]_to_[path]    Delete existing file" << endl;
    cout << "  idl_[file]_to_[path]    Create and edit file" << endl;
    cout << "  run_[file]_to_[path]    Run file with default program" << endl << endl;
    
    cout << "Directory Operations:" << endl;
    cout << "  cd_[path]               Change current directory" << endl;
    cout << "  tra_[path]              List files with details" << endl;
    cout << "  md_[path]               Create new directory" << endl;
    cout << "  rd_[path]               Remove existing directory" << endl << endl;
    
    cout << "System Commands:" << endl;
    cout << "  ::color [code]          Change screen color (e.g. ::color 0A)" << endl;
    cout << "  ::date                  Show current date and time" << endl;
    cout << "  ::help                  Display this help message" << endl;
    cout << "  ::cls                   Clear screen (keep commands)" << endl;
    cout << "  ::game                  Play number guessing game" << endl;
    cout << "  exit                    Shutdown C-DOS" << endl << endl;
    
    cout << "::color Command Guide:" << endl;
    cout << "  Format: ::color [background][text]" << endl;
    cout << "  Example: ::color 0A = Black background + Green text" << endl << endl;
    cout << "  Color Codes (0-9, A-F):" << endl;
    cout << "  0=Black       1=Blue        2=Green      3=Cyan" << endl;
    cout << "  4=Red         5=Magenta     6=Brown      7=Light Gray" << endl;
    cout << "  8=Dark Gray   9=Light Blue  A=Light Green B=Light Cyan" << endl;
    cout << "  C=Light Red   D=Light Magenta E=Yellow    F=White" << endl << endl;
    cout << "  Recommended combinations:" << endl;
    cout << "  ::color 07 (Black+White)   ::color 02 (Black+Green)" << endl;
    cout << "  ::color 1F (Blue+White)    ::color 4E (Red+Yellow)" << endl;
    cout << "====================================" << endl;
}

// ����Ŀ¼����
bool makeDirectory(const string& path) {
    string fullPath = path;
    normalizeDriveLetter(fullPath);
    
    if (fullPath.find(":\\") == string::npos) {
        fullPath = g_currentDir + fullPath;
    }
    
    if (_mkdir(fullPath.c_str()) == 0) {
        printSuccess("Directory created: " + fullPath);
        return true;
    } else {
        printError("Failed to create directory: " + fullPath);
        printError("Possible reasons: already exists, invalid path, or permissions");
        return false;
    }
}

// �Ƴ�Ŀ¼����
bool removeDirectory(const string& path) {
    string fullPath = path;
    normalizeDriveLetter(fullPath);
    
    if (fullPath.find(":\\") == string::npos) {
        fullPath = g_currentDir + fullPath;
    }
    
    if (_rmdir(fullPath.c_str()) == 0) {
        printSuccess("Directory removed: " + fullPath);
        return true;
    } else {
        printError("Failed to remove directory: " + fullPath);
        printError("Possible reasons: does not exist, not empty, or permissions");
        return false;
    }
}

// ��������
void clearScreen() {
    system("cls");
    cout << "\n[Supported Commands Summary]" << endl;
    cout << "new_[file]_to_[path]  - Create empty file" << endl;
    cout << "del_[file]_to_[path]  - Delete existing file" << endl;
    cout << "idl_[file]_to_[path]  - Create and write file" << endl;
    cout << "run_[file]_to_[path]  - Run file with default program" << endl;
    cout << "cd_[path]             - Change current directory" << endl;
    cout << "tra_[path]            - List files (with size/time)" << endl;
    cout << "md_[path]             - Create new directory" << endl;
    cout << "rd_[path]             - Remove existing directory" << endl;
    cout << "::color [code]        - Change screen color" << endl;
    cout << "::date                - Show current date/time" << endl;
    cout << "::help                - Display help information" << endl;
    cout << "::game                - Play number guessing game" << endl;
    cout << "::cls                 - Clear screen (keep commands)" << endl;
    cout << "exit                  - Shutdown C-DOS" << endl;
}

// �����������
bool parseCommand(const string& command, string& operation, string& param1, string& param2) {
    if (command == "::game") {
        operation = "game";
        return true;
    }
    else if (command == "::cls") {
        operation = "cls";
        return true;
    }
    else if (command == "::date") {
        operation = "date";
        return true;
    }
    else if (command == "::help") {
        operation = "help";
        return true;
    }
    else if (command.substr(0, 7) == "::color") {
        operation = "color";
        if (command.length() < 9) {
            param1 = "";
        } else {
            param1 = command.substr(8);
        }
        return true;
    }
    else if (command.substr(0, 3) == "cd_") {
        operation = "cd";
        param1 = command.substr(3);
        return true;
    }
    else if (command.substr(0, 4) == "del_") {
        operation = "delete";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        param1 = command.substr(4, delPos - 4);
        param2 = command.substr(delPos + 4);
        return true;
    }
    else if (command.substr(0, 4) == "new_") {
        operation = "create";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        param1 = command.substr(4, delPos - 4);
        param2 = command.substr(delPos + 4);
        return true;
    }
    else if (command.substr(0, 4) == "idl_") {
        operation = "write";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        param1 = command.substr(4, delPos - 4);
        param2 = command.substr(delPos + 4);
        return true;
    }
    else if (command.substr(0, 4) == "tra_") {
        operation = "traverse";
        param1 = command.substr(4);
        return true;
    }
    else if (command.substr(0, 4) == "run_") {
        operation = "run";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        param1 = command.substr(4, delPos - 4);
        param2 = command.substr(delPos + 4);
        return true;
    }
    else if (command.substr(0, 3) == "md_") {
        operation = "md";
        param1 = command.substr(3);
        return true;
    }
    else if (command.substr(0, 3) == "rd_") {
        operation = "rd";
        param1 = command.substr(3);
        return true;
    }
    return false;
}

// ���������
void processCommand(const string& command) {
    if (command == "exit") {
        cout << "Shutting down C-DOS..." << endl;
        delay(1000);
        exit(0);
    }

    if (!command.empty()) {
        string operation, param1, param2;
        if (parseCommand(command, operation, param1, param2)) {
            if (operation == "cd") {
                changeDirectory(param1);
            } else if (operation == "traverse") {
                traverseDirectoryEnhanced(param1);
            } else if (operation == "create") {
                createFileWithPath(param1, param2);
            } else if (operation == "delete") {
                deleteFileWithPath(param1, param2);
            } else if (operation == "write") {
                writeFileWithPath(param1, param2);
            } else if (operation == "run") {
                runFileWithPath(param1, param2);
            } else if (operation == "game") {
                startGame();
            } else if (operation == "cls") {
                clearScreen();
            } else if (operation == "color") {
                changeColor(param1);
            } else if (operation == "date") {
                showDateTime();
            } else if (operation == "help") {
                showHelp();
            } else if (operation == "md") {
                makeDirectory(param1);
            } else if (operation == "rd") {
                removeDirectory(param1);
            }
        } else {
            printError("\nInvalid command! Type ::help for assistance");
            printCommandSummary();
        }
    }
}

// ������ܴ�ӡ����
void printCommandSummary() {
    cout << "new_[file]_to_[path]  - Create empty file" << endl;
    cout << "del_[file]_to_[path]  - Delete file" << endl;
    cout << "idl_[file]_to_[path]  - Write file content" << endl;
    cout << "run_[file]_to_[path]  - Run file" << endl;
    cout << "cd_[path]             - Change directory" << endl;
    cout << "tra_[path]            - List directory contents" << endl;
    cout << "md_[path]             - Create new directory" << endl;
    cout << "rd_[path]             - Remove existing directory" << endl;
    cout << "::color [code]        - Change screen color" << endl;
    cout << "::date                - Show current date/time" << endl;
    cout << "::help                - Display help information" << endl;
    cout << "::game                - Start guessing game" << endl;
    cout << "::cls                 - Clear screen (keep commands)" << endl;
    cout << "exit                  - Exit C-DOS" << endl;
}

// �����뽻��
void bootCdos() {
    system(COLOR_DEFAULT.c_str());
    cout << "C-DOS Version 1.30 (C) Copyright 2023 C-DOS Development Team" << endl;
    cout << "System BIOS v1.0.8 - Initializing hardware..." << endl;
    delay(800);
    cout << "640K conventional memory detected (OK)" << endl;
    delay(600);
    cout << "Drive C: 200MB Fixed Disk (Active Partition)" << endl;
    delay(700);
    cout << "COMMAND.COM loaded - Shell ready" << endl;
    delay(300);
    
    printCommandSummary();
}

void commandLine() {
    string command;
    while (true) {
        cout << endl << g_currentDir << ">";
        getline(cin, command);
        processCommand(command);
    }
}

// ������
int main() {
    initCurrentDir();
    bootCdos();
    commandLine();
    return 0;
}
