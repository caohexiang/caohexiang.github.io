#include <iostream>
#include <fstream>
#include <string>
#include <windows.h>
#include <sstream>
#include <cctype>
#include <io.h>
#include <ctime>
#include <direct.h>
#include <iomanip>

using namespace std;

// -------------------------- 1. ��ǰ�������к��������"δ����"���� --------------------------
// ���ߺ���
void delay(DWORD milliseconds);
void normalizeDriveLetter(string& path);
void printColored(const string& message, const string& colorCode);
void printError(const string& message);
void printWritePrompt(const string& message);
void printList(const string& message);
void printSuccess(const string& message);
void printGame(const string& message);
string formatFileTime(time_t fileTime);  // ʱ���ʽ������
string intToString(long long num);       // ��� to_string ���Զ��庯��

// ���Ĺ��ܺ���
bool createFileWithPath(const string& filename, const string& directory);
bool deleteFileWithPath(const string& filename, const string& directory);
bool writeFileWithPath(const string& filename, const string& directory);
bool traverseDirectoryEnhanced(const string& path);
bool runFileWithPath(const string& filename, const string& directory);
void startGame();
bool changeDirectory(const string& targetDir);

// ���������ַ�
bool parseCommand(const string& command, string& operation, string& filename, string& directory);
void processCommand(const string& command);

// ϵͳ����
void initCurrentDir();
void bootCdos();
void commandLine();

// -------------------------- 2. ȫ�ֱ����볣�� --------------------------
string g_currentDir;  // ��ǰ����Ŀ¼

// ��ɫ���Ƴ���
const string COLOR_DEFAULT = "color 07";
const string COLOR_ERROR = "color 0C";
const string COLOR_PROMPT = "color 0A";
const string COLOR_LIST = "color 0B";
const string COLOR_SUCCESS = "color 0F";
const string COLOR_GAME = "color 0E";

// -------------------------- 3. ���ߺ���ʵ�֣��޸�C++98�������⣩ --------------------------
// �ӳٺ���
void delay(DWORD milliseconds) {
    Sleep(milliseconds);
}

// ��׼����������ĸ��c: -> C:��
void normalizeDriveLetter(string& path) {
    if (path.length() >= 2 && path[1] == ':' && tolower(path[0]) == 'c') {
        path[0] = 'C';
    }
}

// ����ɫ������������б�������
void printColored(const string& message, const string& colorCode) {
    system(colorCode.c_str());
    cout << message << endl;
    system(COLOR_DEFAULT.c_str());
}

// �򻯴������
void printError(const string& message) {
    printColored(message, COLOR_ERROR);
}

// �򻯱�дģʽ��ʾ
void printWritePrompt(const string& message) {
    printColored(message, COLOR_PROMPT);
}

// ���б����
void printList(const string& message) {
    printColored(message, COLOR_LIST);
}

// �򻯳ɹ���Ϣ���
void printSuccess(const string& message) {
    printColored(message, COLOR_SUCCESS);
}

// ����Ϸ��Ϣ���
void printGame(const string& message) {
    printColored(message, COLOR_GAME);
}

// �Զ���intתstring�����C++11��to_string������C++98��
string intToString(long long num) {
    stringstream ss;
    ss << num;
    return ss.str();
}

// ʱ���ʽ�����޸�iomanip�÷�������C++98��
string formatFileTime(time_t fileTime) {
    struct tm* localTime = localtime(&fileTime);
    if (localTime == NULL) return "Unknown Time";

    stringstream ss;
    // �޸����ֲ������ø�ʽ��������ʽ���ó�ͻ
    ss << setfill('0');  // ��������ַ�Ϊ0
    ss << setw(4) << (localTime->tm_year + 1900) << "-";  // �꣨4λ��
    ss << setw(2) << (localTime->tm_mon + 1) << "-";      // �£�2λ��
    ss << setw(2) << localTime->tm_mday << " ";           // �գ�2λ��
    ss << setw(2) << localTime->tm_hour << ":";           // ʱ��2λ��
    ss << setw(2) << localTime->tm_min;                   // �֣�2λ��
    return ss.str();
}

// ��ʼ����ǰ����Ŀ¼
void initCurrentDir() {
    char buffer[256];
    if (_getcwd(buffer, sizeof(buffer)) != NULL) {
        g_currentDir = buffer;
        if (g_currentDir[g_currentDir.length() - 1] != '\\') {
            g_currentDir += "\\";
        }
    } else {
        g_currentDir = "C:\\";
    }
}

// -------------------------- 4. Ŀ¼�������ܣ�cd���� + ��ǿtra��� --------------------------
// cd����л�Ŀ¼
bool changeDirectory(const string& targetDir) {
    string normalizedDir = targetDir;
    normalizeDriveLetter(normalizedDir);

    // ��������/���·��
    string fullDir;
    if (normalizedDir.empty()) {
        printError("Invalid directory: empty path");
        return false;
    }
    if (normalizedDir.find(":\\") != string::npos) {
        fullDir = normalizedDir;  // ����·��
    } else {
        fullDir = g_currentDir + normalizedDir;  // ���·��
    }
    if (fullDir[fullDir.length() - 1] != '\\') {
        fullDir += "\\";
    }

    // ���Ŀ¼�Ƿ����
    if (_chdir(fullDir.c_str()) != 0) {
        printError("Failed to enter directory: " + fullDir);
        printError("Reason: Directory not found or no access permission");
        return false;
    }

    // ���µ�ǰĿ¼
    g_currentDir = fullDir;
    printSuccess("Current directory changed to: " + g_currentDir);
    return true;
}

// ��ǿtra�����ʾ�ļ���С���޸�ʱ��
bool traverseDirectoryEnhanced(const string& path) {
    string targetPath = path;
    normalizeDriveLetter(targetPath);

    // ��������/���·��
    string fullPath;
    if (targetPath.find(":\\") != string::npos) {
        fullPath = targetPath;
    } else {
        fullPath = g_currentDir + targetPath;
    }
    if (fullPath[fullPath.length() - 1] != '\\') {
        fullPath += "\\";
    }

    // ����Ŀ¼��ʹ��_findfirst/_findnext������C++98��
    string searchPath = fullPath + "*.*";
    _finddata_t fileInfo;
    intptr_t handle = _findfirst(searchPath.c_str(), &fileInfo);

    if (handle == -1L) {
        printError("Directory not found or access denied: " + fullPath);
        return false;
    }

    // �����ͷ���޸���ʽ���ƣ�����C++98��
    printList("\nDirectory of: " + fullPath);
    printList("----------------------------------------------------------------------");
    cout << left;  // �����
    cout << setw(8) << "[Type]" << setw(25) << "Name" 
         << setw(15) << "Size (Bytes)" << "Modify Time" << endl;
    printList("----------------------------------------------------------------------");

    int fileCount = 0;
    long long totalSize = 0;
    do {
        // ����.��..Ŀ¼
        if (strcmp(fileInfo.name, ".") == 0 || strcmp(fileInfo.name, "..") == 0) {
            continue;
        }

        // ƴ��ÿһ�����ݣ�ʹ���Զ���intToString�����to_string��
        string typeStr = (fileInfo.attrib & _A_SUBDIR) ? "[DIR]" : "[FILE]";
        string nameStr = fileInfo.name;
        if (fileInfo.attrib & _A_SUBDIR) {
            nameStr += "\\";
        } else {
            totalSize += fileInfo.size;
        }
        string sizeStr = (fileInfo.attrib & _A_SUBDIR) ? "-" : intToString(fileInfo.size);
        string timeStr = formatFileTime(fileInfo.time_write);

        // ��ʽ��������޸�setw�÷���
        stringstream lineSS;
        lineSS << left << setw(8) << typeStr << setw(25) << nameStr 
               << setw(15) << sizeStr << timeStr;
        printList(lineSS.str());
        fileCount++;
    } while (_findnext(handle, &fileInfo) == 0);

    _findclose(handle);

    // ���ͳ����Ϣ
    printList("----------------------------------------------------------------------");
    cout << "Total items: " << fileCount << " | Total file size: " << totalSize << " bytes" << endl;
    return true;
}

// -------------------------- 5. �ļ��������ܣ�create/delete/write/run�� --------------------------
// �������ļ�
bool createFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    // ����ļ��Ƿ��Ѵ���
    if (checkFile.good()) {
        checkFile.close();
        printError("File already exists: " + fullPath);
        return false;
    }

    // �����ļ�
    ofstream newFile(fullPath.c_str());
    if (newFile.is_open()) {
        newFile.close();
        cout << "Empty file created: " << fullPath << endl;
        return true;
    } else {
        printError("Failed to create file: " + fullPath);
        printError("Check directory existence and permissions");
        return false;
    }
}

// ɾ���ļ�
bool deleteFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    // ����ļ��Ƿ����
    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    // ִ��ɾ��
    if (DeleteFileA(fullPath.c_str())) {
        cout << "File deleted: " << fullPath << endl;
        return true;
    } else {
        stringstream ss;
        ss << GetLastError();
        printError("Failed to delete file: " + fullPath);
        printError("Error code: " + ss.str() + " (file may be in use)");
        return false;
    }
}

// ��д�ļ�����
bool writeFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ofstream writeFile(fullPath.c_str());

    if (!writeFile.is_open()) {
        printError("Failed to open file for writing: " + fullPath);
        printError("Check directory existence and permissions");
        return false;
    }

    // ��дģʽ��ʾ
    printWritePrompt("\n=== Write Mode Activated ===");
    printWritePrompt("Tips: 1. Enter content line by line");
    printWritePrompt("      2. Type '::save' to save and exit");
    printWritePrompt("      3. Type '::cancel' to discard and exit");
    printWritePrompt("===========================");

    string inputLine;
    while (true) {
        system(COLOR_PROMPT.c_str());
        cout << "[Write] > ";
        system(COLOR_DEFAULT.c_str());
        getline(cin, inputLine);

        if (inputLine == "::save") {
            writeFile.close();
            cout << endl << "Content saved to: " << fullPath << endl;
            return true;
        } else if (inputLine == "::cancel") {
            writeFile.close();
            DeleteFileA(fullPath.c_str());
            printError("\nWrite canceled - file discarded");
            return false;
        } else {
            writeFile << inputLine << endl;
        }
    }
}

// �����ļ�
bool runFileWithPath(const string& filename, const string& directory) {
    string fullPath = directory + filename;
    ifstream checkFile(fullPath.c_str());

    if (!checkFile.good()) {
        checkFile.close();
        printError("File not found: " + fullPath);
        return false;
    }
    checkFile.close();

    // �����ļ���ʹ��ShellExecuteA������32/64λ��
    printSuccess("Trying to run file: " + fullPath);
    printSuccess("Please wait...");
    HINSTANCE result = ShellExecuteA(0, "open", fullPath.c_str(), NULL, NULL, SW_SHOWNORMAL);

    // ������н����ʹ��intptr_t���⾫�ȶ�ʧ��
    if ((intptr_t)result > 32) {
        printSuccess("File started successfully: " + filename);
        return true;
    } else {
        stringstream ss;
        ss << (intptr_t)result;
        printError("Failed to run file: " + fullPath);
        printError("Error code: " + ss.str());
        printError("Possible reasons: no default program, or file is not executable");
        return false;
    }
}

// -------------------------- 6. ��Ϸ���� --------------------------
void startGame() {
    system(COLOR_GAME.c_str());
    cout << "\n====================================" << endl;
    cout << "          Number Guessing Game       " << endl;
    cout << "====================================" << endl;
    cout << "I'm thinking of a number between 1 and 100" << endl;
    cout << "Can you guess what it is?" << endl;
    cout << "Type 'quit' to exit the game" << endl;
    cout << "====================================" << endl;

    // ��ʼ�������
    srand((unsigned int)time(NULL));
    int secretNumber = rand() % 100 + 1;
    int guess;
    int attempts = 0;
    string input;

    while (true) {
        cout << "\nEnter your guess: ";
        getline(cin, input);

        // �˳���Ϸ
        if (input == "quit") {
            stringstream ss;
            ss << secretNumber;
            printError("\nThanks for playing! The secret number was: " + ss.str());
            system(COLOR_DEFAULT.c_str());
            return;
        }

        // ��������
        stringstream ss(input);
        if (!(ss >> guess)) {
            printError("Please enter a valid number or 'quit' to exit");
            continue;
        }

        attempts++;

        // �жϽ��
        if (guess < 1 || guess > 100) {
            printError("Please enter a number between 1 and 100");
        } else if (guess < secretNumber) {
            printGame("Too low! Try a higher number");
        } else if (guess > secretNumber) {
            printGame("Too high! Try a lower number");
        } else {
            system(COLOR_SUCCESS.c_str());
            cout << "\n====================================" << endl;
            cout << "Congratulations! You guessed the number!" << endl;
            cout << "The secret number was: " << secretNumber << endl;
            cout << "You did it in " << attempts << " attempts!" << endl;
            cout << "====================================" << endl;
            system(COLOR_DEFAULT.c_str());
            return;
        }
    }
}

// -------------------------- 7. ���������ַ� --------------------------
bool parseCommand(const string& command, string& operation, string& filename, string& directory) {
    // ��Ϸ����
    if (command == "::game") {
        operation = "game";
        return true;
    }
    // cd����
    else if (command.substr(0, 3) == "cd_") {
        operation = "cd";
        directory = command.substr(3);
        filename = "";
    }
    // del����
    else if (command.substr(0, 4) == "del_") {
        operation = "delete";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    // new����
    else if (command.substr(0, 4) == "new_") {
        operation = "create";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    // idl����
    else if (command.substr(0, 4) == "idl_") {
        operation = "write";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    // tra����
    else if (command.substr(0, 4) == "tra_") {
        operation = "traverse";
        directory = command.substr(4);
        filename = "";
    }
    // run����
    else if (command.substr(0, 4) == "run_") {
        operation = "run";
        size_t delPos = command.find("_to_", 4);
        if (delPos == string::npos) return false;
        filename = command.substr(4, delPos - 4);
        directory = command.substr(delPos + 4);
    }
    // ��Ч����
    else {
        return false;
    }

    // ·��������֧�����·��.��
    if (operation != "traverse" && operation != "game" && operation != "cd") {
        if (directory == ".") {
            directory = g_currentDir;
        } else {
            normalizeDriveLetter(directory);
            if (!directory.empty() && directory[directory.length() - 1] != '\\') {
                directory += "\\";
            }
        }
    }
    return true;
}

void processCommand(const string& command) {
    // �˳�����
    if (command == "exit") {
        cout << "Shutting down C-DOS..." << endl;
        delay(1000);
        exit(0);
    }

    if (!command.empty()) {
        string operation, filename, directory;
        if (parseCommand(command, operation, filename, directory)) {
            // �ַ�����
            if (operation == "cd") {
                changeDirectory(directory);
            } else if (operation == "traverse") {
                traverseDirectoryEnhanced(directory);
            } else if (operation == "create") {
                createFileWithPath(filename, directory);
            } else if (operation == "delete") {
                deleteFileWithPath(filename, directory);
            } else if (operation == "write") {
                writeFileWithPath(filename, directory);
            } else if (operation == "run") {
                runFileWithPath(filename, directory);
            } else if (operation == "game") {
                startGame();
            }
        } else {
            // ��Ч������ʾ
            printError("\nInvalid command format!");
            printError("Supported commands:");
            printError("1. Create file: new_[file]_to_[path]  (e.g. new_note.txt_to_C:\\Desktop)");
            printError("2. Delete file: del_[file]_to_[path]  (e.g. del_note.txt_to_C:\\Desktop)");
            printError("3. Write file: idl_[file]_to_[path]  (e.g. idl_note.txt_to_C:\\Desktop)");
            printError("4. Run file:   run_[file]_to_[path]  (e.g. run_pic.jpg_to_C:\\Pics)");
            printError("5. Change dir: cd_[path]            (e.g. cd_C:\\Users\\CHX\\Desktop)");
            printError("6. Traverse dir: tra_[path]         (e.g. tra_. or tra_C:\\Desktop)");
            printError("7. Play game:  ::game");
            printError("8. Exit:       exit");
        }
    }
}

// -------------------------- 8. ϵͳ�����������н��� --------------------------
void bootCdos() {
    system(COLOR_DEFAULT.c_str());  // ��ʼ��Ĭ����ɫ
   	cout << "C-DOS Version 1.09 (C) Copyright 1995 C-DOS Development Team" << endl;
    
    cout << "System BIOS v1.0.5 - Initializing hardware..." << endl;
    delay(800);
	cout<<endl<<endl;
    cout << "Checking system memory..." << endl;
    delay(600);
    cout << "640K conventional memory detected (OK)" << endl;
    delay(400);

    cout << "Checking disk drives..." << endl;
    cout<<endl;
    delay(700);
    cout << "Drive A: 3.5\" 1.44MB Floppy Disk (Ready)" << endl;
    cout << "Drive C: 200MB Fixed Disk (Active Partition)" << endl;
    delay(500);
	cout<<endl;
    cout << "Loading system components..." << endl;
    delay(600);
    cout << "IO.SYS loaded (v1.0)" << endl;
    delay(700);
    cout << "MSDOS.SYS loaded (v1.0)" << endl;
    delay(500);
    cout << "COMMAND.COM loaded (v1.0) - Shell ready" << endl;

    cout << endl << "C-DOS startup completed successfully" << endl;
    delay(300);
    cout << "\n[Supported Commands Summary]" << endl;
    cout << "new_[file]_to_[path]  - Create empty file" << endl;
    cout << "del_[file]_to_[path]  - Delete existing file" << endl;
    cout << "idl_[file]_to_[path]  - Create and write file" << endl;
    cout << "run_[file]_to_[path]  - Run file with default program" << endl;
    cout << "cd_[path]            - Change current directory" << endl;
    cout << "tra_[path]            - List files (with size/time)" << endl;
    cout << "::game                - Play number guessing game" << endl;
    cout << "exit                  - Shutdown C-DOS" << endl;
}

void commandLine() {
    string command;
    while (true) {
        cout << endl << g_currentDir << ">";  // ��ʾ��ǰĿ¼��Ϊ��ʾ��
        getline(cin, command);
        processCommand(command);
    }
}

// -------------------------- 9. ������ --------------------------
int main() {
    initCurrentDir();  // ��ʼ����ǰĿ¼
    bootCdos();        // ��������
    commandLine();     // �����н���
    return 0;
}
