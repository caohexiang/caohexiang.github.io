CDOS USER MANUAL (EXCLUDING COPY FUNCTION)

1. SYSTEM STARTUP
When you start your computer with CDOS, you'll see the system prompt after initialization:
C:\>
This indicates the system is ready to accept commands.

2. BASIC NAVIGATION COMMANDS

2.1 CD (Change Directory)
Purpose: Navigate between directories
Syntax: cd_[directory_path]
Examples:
- cd_Documents - Move to the Documents directory
- cd_.. - Move to the parent directory
- cd_C:\Windows - Move directly to the Windows directory on drive C

2.2 TRA (Traverse Directory)
Purpose: List contents of a directory
Syntax: tra_[directory_path]
Examples:
- tra_. - List current directory contents
- tra_Downloads - List contents of the Downloads directory
- tra_C:\ - List root directory of drive C

3. FILE MANAGEMENT COMMANDS

3.1 NEW (Create New File)
Purpose: Create an empty file
Syntax: new_[filename]_to_[directory]
Example: new_report.txt_to_Documents

3.2 DEL (Delete File)
Purpose: Remove a file
Syntax: del_[filename]_to_[directory]
Example: del_oldfile.txt_to_.

3.3 IDL (Edit File)
Purpose: Create and edit a file
Syntax: idl_[filename]_to_[directory]
Example: idl_notes.txt_to_Desktop
After executing, type your content and use ::save to save or ::cancel to discard changes.

3.4 RUN (Execute File)
Purpose: Run a program or file with its default application
Syntax: run_[filename]_to_[directory]
Example: run_program.exe_to_Applications

4. DIRECTORY MANAGEMENT COMMANDS

4.1 MD (Make Directory)
Purpose: Create a new directory
Syntax: md_[directory_path]
Example: md_Projects\NewProject

4.2 RD (Remove Directory)
Purpose: Delete an empty directory
Syntax: rd_[directory_path]
Example: rd_OldFiles
Note: Directory must be empty to be removed

5. SYSTEM COMMANDS

5.1 ::COLOR
Purpose: Change screen color
Syntax: ::color [2-digit_hex_code]
Examples:
- ::color 0A - Black background with green text
- ::color 70 - White background with black text

5.2 ::DATE
Purpose: Display current date and time
Syntax: ::date

5.3 ::HELP
Purpose: Show help information
Syntax: ::help

5.4 ::CLS
Purpose: Clear the screen
Syntax: ::cls

5.5 ::GAME
Purpose: Start the number guessing game
Syntax: ::game

5.6 EXIT
Purpose: Shutdown CDOS
Syntax: exit

6. ERROR CODES
- 0x0001: File not found - Check file path and name
- 0x0002: Permission denied - Verify directory permissions
- 0x0003: Directory not empty - Clear contents before deleting directory
- 0x0004: Invalid command - Check syntax and try again

7. NOTES
- Replace [ ] placeholders with actual names/paths
- Use backslashes (\) to separate directories in paths
- Current directory is indicated before the > prompt
- Commands are case-insensitive but traditionally typed in uppercase